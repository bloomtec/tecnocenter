$(document).ready(function() {
    $("#fecha_inicial").datepicker();
  });