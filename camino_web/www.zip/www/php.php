<?php
phpinfo();

?>